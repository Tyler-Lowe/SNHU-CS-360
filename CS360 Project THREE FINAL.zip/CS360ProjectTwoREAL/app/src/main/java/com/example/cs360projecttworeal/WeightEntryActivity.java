package com.example.cs360projecttworeal;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class WeightEntryActivity extends AppCompatActivity {

    DatabaseHelper databaseHelper;
    EditText weightInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_entry);  // Ensure activity_weight_entry.xml exists

        // Initialize DatabaseHelper and EditText
        databaseHelper = new DatabaseHelper(this);
        weightInput = findViewById(R.id.weightInput);
    }

    // Method to save the daily weight entry
    public void saveDailyWeight(View view) {
        String weight = weightInput.getText().toString();

        if (!weight.isEmpty()) {
            String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(System.currentTimeMillis());
            boolean isInserted = databaseHelper.addWeight(currentDate, Double.parseDouble(weight));

            if (isInserted) {
                Toast.makeText(this, "Weight saved successfully!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Error saving weight!", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please enter a weight!", Toast.LENGTH_SHORT).show();
        }
    }
}
