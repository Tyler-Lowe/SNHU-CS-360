package com.example.cs360projecttworeal;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);  // Ensure activity_login.xml exists in res/layout
        databaseHelper = new DatabaseHelper(this);  // Initialize the database helper
    }

    // Method to process user login
    public void processUserCredentials(View view) {
        String username = ((EditText) findViewById(R.id.username)).getText().toString();
        String password = ((EditText) findViewById(R.id.password)).getText().toString();

        // Check if the user exists in the database
        if (databaseHelper.userExists(username, password)) {
            Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
            // Redirect to the next activity (e.g., WeightEntryActivity)
        } else {
            Toast.makeText(this, "Invalid credentials, please try again.", Toast.LENGTH_SHORT).show();
        }
    }
}
