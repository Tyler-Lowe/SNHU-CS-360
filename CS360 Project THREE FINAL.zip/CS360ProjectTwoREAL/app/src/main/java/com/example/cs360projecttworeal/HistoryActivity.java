package com.example.cs360projecttworeal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import android.database.Cursor;
import android.os.Bundle;

public class HistoryActivity extends AppCompatActivity {

    DatabaseHelper databaseHelper;
    RecyclerView recyclerView;
    HistoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);  // Ensure activity_history.xml exists

        // Initialize DatabaseHelper and RecyclerView
        databaseHelper = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.weightHistoryRecyclerView);

        // Fetch the weight history from the database
        Cursor cursor = databaseHelper.getAllWeights();

        // Set up the adapter with the retrieved data
        adapter = new HistoryAdapter(cursor);
        recyclerView.setAdapter(adapter);
    }
}

