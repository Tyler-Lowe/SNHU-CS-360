package com.example.cs360projecttworeal;

import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder> {

    private final Cursor cursor;

    public HistoryAdapter(Cursor cursor) {
        this.cursor = cursor;
    }

    @Override
    public HistoryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.history_item, parent, false);
        return new HistoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(HistoryViewHolder holder, int position) {
        if (cursor.moveToPosition(position)) {
            String date = cursor.getString(cursor.getColumnIndex("date"));  // Make sure 'date' exists in your database
            double weight = cursor.getDouble(cursor.getColumnIndex("weight"));  // Make sure 'weight' exists in your database

            holder.dateTextView.setText(date);
            holder.weightTextView.setText(String.valueOf(weight));
        }
    }

    @Override
    public int getItemCount() {
        return cursor.getCount();
    }

    public static class HistoryViewHolder extends RecyclerView.ViewHolder {
        TextView dateTextView;
        TextView weightTextView;

        public HistoryViewHolder(View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
            weightTextView = itemView.findViewById(R.id.weightTextView);
        }
    }
}
