package com.example.cs360projecttworeal;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AccountActivity extends AppCompatActivity {

    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);  // Ensure this layout file exists
        databaseHelper = new DatabaseHelper(this);  // Ensure DatabaseHelper has a valid constructor
    }

    public void createNewAccount(View view) {
        String username = ((EditText) findViewById(R.id.username)).getText().toString();
        String password = ((EditText) findViewById(R.id.password)).getText().toString();

        if (databaseHelper.addUser(username, password)) {
            Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show();
            finish(); // Return to LoginActivity
        } else {
            Toast.makeText(this, "Failed to create account. Try again.", Toast.LENGTH_SHORT).show();
        }
    }
}


